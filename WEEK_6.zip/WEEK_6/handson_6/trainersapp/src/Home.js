import React from 'react';

const Home = () => {
  return (
    <div>
      <h2>Welcome to my academy trainers App</h2>
    </div>
  );
};

export default Home;
