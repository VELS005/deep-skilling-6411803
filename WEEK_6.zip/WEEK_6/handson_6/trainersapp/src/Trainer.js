class Trainer {
  constructor(id, name, email, phone, technology, skills) {
    this.TrainerId = id;
    this.Name = name;
    this.Email = email;
    this.Phone = phone;
    this.Technology = technology;
    this.Skills = skills;
  }
}

export default Trainer;
