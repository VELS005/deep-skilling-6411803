import Trainer from './Trainer';

const trainers = [
  new Trainer('t-syed8','syed khaleel','syed khaleelah@cognizant.com','97676516962','.NET',['C','SQL server','React','.NETcore']),
  new Trainer('t-jogo','jogo jose','jojgo@cognizant.com','9897199231','java',['java','jsp','angular','spring']),
  new Trainer('t-elisa','Elisa jones','elisa@cognizant.com','9871212235','python',['python','django','angular'])]

export default trainers;