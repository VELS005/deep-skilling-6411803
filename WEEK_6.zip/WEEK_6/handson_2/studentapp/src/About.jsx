import React,{Component} from "react"
export class About extends Component{
  render(){
    return(
    <div>
    <h2>Welcome to the about page of student management portal</h2>
    </div>)
  }
}