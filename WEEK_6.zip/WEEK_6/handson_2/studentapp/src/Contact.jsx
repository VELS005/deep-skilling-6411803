import React,{Component} from "react"
export class Contact extends Component{
  render(){
    return(
    <div>
    <h2>Welcome to the contact page of student management portal</h2>
    </div>)
  }
} 