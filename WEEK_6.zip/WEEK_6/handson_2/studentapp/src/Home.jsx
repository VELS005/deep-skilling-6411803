import React,{Component} from "react";
export class Home extends Component{
  render(){
    return(
    <div>
    <h2>Welcome to the home page of Student management portal</h2>
    </div>)
  }
}