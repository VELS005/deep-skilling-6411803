package WEEK_1.design_patterns.factory_pattern.code;

public class pdfdocument implements document {
  public void open(){
    System.out.println("pdf document is opening");
  }
  
}
