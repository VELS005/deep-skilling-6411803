package WEEK_1.design_patterns.factory_pattern.code;

public interface document {
  void open();  
} 
