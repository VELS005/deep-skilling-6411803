package WEEK_1.design_patterns.factory_pattern.code;

public abstract class documentfactory {
  public abstract document createDocument();
  
}
