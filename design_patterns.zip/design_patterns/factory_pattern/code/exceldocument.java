package WEEK_1.design_patterns.factory_pattern.code;

public class exceldocument implements document {
  public void open(){
    System.out.println("excel document is opening");
  }
  
}
